/* 
* Lysa Hannes
* 6695100
* COSC 3P98 Assignemnt 1 Question 2
* I used this example from the course website to help me with perspective: http://www.cosc.brocku.ca/Offerings/3P98/course/lectures/3d_perspective/cube_persp.c
* I used this example from the course website to help me with making the cube: http://www.cosc.brocku.ca/Offerings/3P98/course/OpenGL/3P98Examples/OpenGLExamples/rotate.c
* I used the first post from this website to find the clock function in c: https://stackoverflow.com/questions/10192903/time-in-milliseconds-in-c
* I used this website fo figure out how to do randome double values: https://stackoverflow.com/questions/63981013/generating-random-double-between-1-and-100-in-c
* I used this website to help me set the framerate constsistant: https://www.youtube.com/watch?v=NT-0Q2Psp2Y
* 
* Bonuses I did:
* c or C toggles different colours
* x or X toggles different sizes
* new effect: a or A toggles slow motion
*/
#define FILENAME "img.tif"

#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <glut.h>
#include <FreeImage.h>
#include <time.h>
#include <windows.h> 

int max = 35; //the x and z values for the floor
int counter = 0; //for knowing which particle number we are on
double currentGravity = 0.0001;
clock_t start, stop, nextParticle, startNextParticle;
int firstClock = 0; //used for tracking if it time to restart the animation speed clocks (start and stop)
int secondClock = 0; //used for tracking if it time to restart the next particle speed clocks (nextParticle and startNextParticle)
int numParticles = -1; //used for spacing out the time between each particles creation
int speed = 0; //speed of the animation
int fireingSpeed = 1;
int colourToggle = 0; //for toggling the colorful mode
int frictionToggle = 0; //for toggling the friction mode 
int nextColor = 0; //for knowing what the next color to use is
int totalNumParticles = 1000; //used for if I want to change the number of max particles easier, there are still some other things that need to be changed though
//so changing this variable alone will cause problems;

/*for particle list
* max 25 particles
* 0 - state - 0 if not on screen, 1 if moving, 2 if its done moving, 3 if it needs to delete
* 1 - 
* 2 - divide bounce
* 3 - r1 value (darkest)
* 4 - g1 value (darkest)
* 5 - b1 value (darkesy)
* 6 - r2 value 
* 7 - g2 value
* 8 - b2 value
* 9 - r3 value (lightest)
* 10 - g3 value (lightest)
* 11 - b3 value (lightest)
*/
int particles[1000][14] = {0};
//20
/*For particle direction
* 0 - x position center
* 1 - y position center
* 2 - z position center
*/
double particlesDir[1000][3] = {0};


//values for the fountain
double a[3] = { 2,4,2 }, b[3] = { 2,0,2 }, c[3] = { -2,0,2 }, d[3] = { -2,4,2 },
e[3] = { 2,4,-2 }, f[3] = { 2,0,-2 }, g[3] = { -2,0,-2 }, h[3] = { -2,4,-2 };
double aa[3] = { 1,8,1 }, bb[3] = { 1,4,1 }, cc[3] = { -1,4,1 }, dd[3] = { -1,8,1 },
ee[3] = { 1,8,-1 }, ff[3] = { 1,4,-1 }, gg[3] = { -1,4,-1 }, hh[3] = { -1,8,-1 };

//values for the floor
double FloorA[3] = { -35,0,35 }, FloorB[3] = { -35,0,-35 }, FloorC[3] = { 35,0,-35 }, FloorD[3] = { 35,0,35 },
FloorE[3] = { 35,-50,-35 }, FloorF[3] = { 35,-50,35 }, FloorG[3] = { -35,-50,35 };

//values for new cube particle
double newCubeA[3] = { 1,1,1 }, newCubeB[3] = { 1,-1,1 }, newCubeC[3] = { -1,-1,1 }, newCubeD[3] = { -1,1,1 },
newCubeE[3] = { 1,1,-1 }, newCubeF[3] = { 1.0,-1.0,-1.0 }, newCubeG[3] = { -1,-1,-1 }, newCubeH[3] = { -1,1,-1 };

//values for new cube particle
double newCubeAVec[1000][3] = { 1,1,1 }, newCubeBVec[1000][3] = { 1,-1,1 }, newCubeCVec[1000][3] = { -1,-1,1 }, newCubeDVec[1000][3] = { -1,1,1 },
newCubeEVec[1000][3] = { 1,1,-1 }, newCubeFVec[1000][3] = { 1.0,-1.0,-1.0 }, newCubeGVec[1000][3] = { -1,-1,-1 }, newCubeHVec[1000][3] = { -1,1,-1 };

//used for bouncing to set the y back to original value
double originalY = 0.05;

//initializes the particles direction
void particleDirection() {

	particlesDir[counter][0] = ((double)rand() / RAND_MAX) * (0.02 - (-0.02)) + (-0.02);
	particlesDir[counter][1] = originalY;
	particlesDir[counter][2] = ((double)rand() / RAND_MAX) * (0.02 - (-0.02)) + (-0.02);
}

//deletes the disapeared cubes from the array to make room for more to get shot
//but this doesnt work as indended and I gave up, I dont think it was a requirement anyways
void deleteParticle() {
	
	int tempCounter = counter;

	for (int i = tempCounter; i < totalNumParticles-1;i++) {
		for (int j = 0; j < 14;j++) {
			particles[i][j] = particles[i+1][j];
		}
	}

	for (int i = tempCounter; i < totalNumParticles-1;i++) {
		for (int j = 0; j < 3;j++) {
			particlesDir[i][j] = particlesDir[i+1][j];
		}
	}

	for (int i = tempCounter; i < totalNumParticles - 1;i++) {
		for (int j = 0; j < 3;j++) {
			newCubeAVec[i][j] = newCubeAVec[i + 1][j];
			newCubeBVec[i][j] = newCubeBVec[i + 1][j];
			newCubeCVec[i][j] = newCubeCVec[i + 1][j];
			newCubeDVec[i][j] = newCubeDVec[i + 1][j];
			newCubeEVec[i][j] = newCubeEVec[i + 1][j];
			newCubeFVec[i][j] = newCubeFVec[i + 1][j];
			newCubeGVec[i][j] = newCubeGVec[i + 1][j];
			newCubeHVec[i][j] = newCubeHVec[i + 1][j];
		}
	}

	counter--;
}

//draws the cube (it wont let me use drawPlane() for some reason here)
void drawCube() {

	glColor3ub(particles[counter][9], particles[counter][10], particles[counter][11]);
	glBegin(GL_QUADS);
	glVertex3dv(newCubeFVec[counter]);
	glVertex3dv(newCubeGVec[counter]);
	glVertex3dv(newCubeCVec[counter]);
	glVertex3dv(newCubeBVec[counter]);
	glEnd();
	//drawPlane(newCubeFVec[counter], newCubeGVec[counter], newCubeCVec[counter], newCubeBVec[counter]);

	glColor3ub((particles[counter][6]), (particles[counter][7]), particles[counter][8]);
	glBegin(GL_QUADS);
	glVertex3dv(newCubeDVec[counter]);
	glVertex3dv(newCubeHVec[counter]);
	glVertex3dv(newCubeGVec[counter]);
	glVertex3dv(newCubeCVec[counter]);
	glEnd();
	//drawPlane(newCubeD, newCubeH, newCubeG, newCubeC);

	glColor3ub(particles[counter][3], particles[counter][4], particles[counter][5]);
	glBegin(GL_QUADS);
	glVertex3dv(newCubeEVec[counter]);
	glVertex3dv(newCubeFVec[counter]);
	glVertex3dv(newCubeGVec[counter]);
	glVertex3dv(newCubeHVec[counter]);
	glEnd();
	//drawPlane(newCubeE, newCubeF, newCubeG, newCubeH);

	glColor3ub(particles[counter][3], particles[counter][4], particles[counter][5]);
	glBegin(GL_QUADS);
	glVertex3dv(newCubeAVec[counter]);
	glVertex3dv(newCubeBVec[counter]);
	glVertex3dv(newCubeCVec[counter]);
	glVertex3dv(newCubeDVec[counter]);
	glEnd();
	//drawPlane(newCubeA, newCubeB, newCubeC, newCubeD);

	glColor3ub(particles[counter][6], particles[counter][7], particles[counter][8]);
	glBegin(GL_QUADS);
	glVertex3dv(newCubeAVec[counter]);
	glVertex3dv(newCubeEVec[counter]);
	glVertex3dv(newCubeFVec[counter]);
	glVertex3dv(newCubeBVec[counter]);
	glEnd();
	//drawPlane(newCubeA, newCubeE, newCubeF, newCubeB);

	glColor3ub(particles[counter][9], particles[counter][10], particles[counter][11]);
	glBegin(GL_QUADS);
	glVertex3dv(newCubeHVec[counter]);
	glVertex3dv(newCubeEVec[counter]);
	glVertex3dv(newCubeAVec[counter]);
	glVertex3dv(newCubeDVec[counter]);
	glEnd();
	//drawPlane(newCubeH, newCubeE, newCubeA, newCubeD);
}

//draws a plane
void drawPlane(double one[3], double two[3], double three[3], double four[3]) {
	glBegin(GL_QUADS);
	glVertex3dv(one);
	glVertex3dv(two);
	glVertex3dv(three);
	glVertex3dv(four);
	glEnd();
}

//draws the fountain
void drawFountain() {

	glClear(GL_COLOR_BUFFER_BIT);

	//floor
	glColor3f(1, 1, 1);
	drawPlane(FloorA, FloorB, FloorC, FloorD);

	glColor3ub(232, 234, 235);
	drawPlane(FloorD, FloorC, FloorE, FloorF);

	glColor3ub(210, 213, 214);
	drawPlane(FloorA, FloorD, FloorF, FloorG);
	
	//shooter bottom
	glColor3ub(101, 106, 110);
	drawPlane(d, h, g, c);

	glColor3ub(85, 89, 92);
	drawPlane(e, f, g, h);

	glColor3ub(85, 89, 92);
	drawPlane(a, b, c, d);

	glColor3ub(101, 106, 110);
	drawPlane(a, e, f, b);

	glColor3ub(132, 137, 140);
	drawPlane(h, e, a, d);

	//shooter top
	glColor3ub(101, 106, 110);
	drawPlane(dd, hh, gg, cc);

	glColor3ub(85, 89, 92);
	drawPlane(ee, ff, gg, hh);

	glColor3ub(85, 89, 92);
	drawPlane(aa, bb, cc, dd);

	glColor3ub(101, 106, 110);
	drawPlane(aa, ee, ff, bb);

	//I decided to take the top off the fountain
	//glColor3ub(132, 137, 140);
	//drawPlane(hh, ee, aa, dd);
}

void setRGB(int r1, int g1, int b1, int r2, int g2, int b2, int r3, int g3, int b3, int particle) {
	particles[particle][3] = r1;
	particles[particle][4] = g1;
	particles[particle][5] = b1;

	particles[particle][6] = r2;
	particles[particle][7] = g2;
	particles[particle][8] = b2;

	particles[particle][9] = r3;
	particles[particle][10] = g3;
	particles[particle][11] = b3;
}

//sets the colors of the cubes, if the color is toggled the next cubes will be different colors
void initColors() {

	if (colourToggle == 1) {

		switch (nextColor) {
		case 0:
			setRGB(63, 133, 176, 99, 180, 230, 179, 210, 230, counter);
			break;
		case 1:
			setRGB(62, 72, 179, 80, 93, 230, 109, 120, 237, counter);
			break;
		case 2:
			setRGB(127, 50, 179, 170, 83, 230, 188, 125, 232, counter);
			break;
		case 3:
			setRGB(176, 60, 159, 214, 81, 195, 240, 113, 222, counter);
			break;
		case 4:
			setRGB(179, 46, 68, 212, 61, 86, 237, 83, 109, counter);
			break;
		case 5:
			setRGB(191, 23, 23, 224, 38, 38, 240, 67, 67, counter);
			break;
		case 6:
			setRGB(196, 83, 18, 235, 111, 40, 240, 128, 65, counter);
			break;
		case 7:
			setRGB(217, 183, 35, 237, 203, 57, 242, 213, 87, counter);
			break;
		case 8:
			setRGB(60, 181, 24, 83, 224, 40, 109, 240, 70, counter);
			break;
		case 9:
			setRGB(47, 214, 150, 71, 237, 174, 128, 224, 188, counter);
			break;
		}
		
		if (nextColor > 9) {
			nextColor = 0;
		}else {
			nextColor++;
		}
		
	}else {
		setRGB(63, 133, 176, 99, 180, 230, 179, 210, 230, counter);
		
	}
}

//initializes each cubes coordinates
void initCubeVectors() {
	newCubeAVec[counter][0] = newCubeA[0];
	newCubeAVec[counter][1] = newCubeA[1] + 9;
	newCubeAVec[counter][2] = newCubeA[2];
	newCubeBVec[counter][0] = newCubeB[0];
	newCubeBVec[counter][1] = newCubeB[1] + 9;
	newCubeBVec[counter][2] = newCubeB[2];
	newCubeCVec[counter][0] = newCubeC[0];
	newCubeCVec[counter][1] = newCubeC[1] + 9;
	newCubeCVec[counter][2] = newCubeC[2];
	newCubeDVec[counter][0] = newCubeD[0];
	newCubeDVec[counter][1] = newCubeD[1] + 9;
	newCubeDVec[counter][2] = newCubeD[2];
	newCubeEVec[counter][0] = newCubeE[0];
	newCubeEVec[counter][1] = newCubeE[1] + 9;
	newCubeEVec[counter][2] = newCubeE[2];
	newCubeFVec[counter][0] = newCubeF[0];
	newCubeFVec[counter][1] = newCubeF[1] + 9;
	newCubeFVec[counter][2] = newCubeF[2];
	newCubeGVec[counter][0] = newCubeG[0];
	newCubeGVec[counter][1] = newCubeG[1] + 9;
	newCubeGVec[counter][2] = newCubeG[2];
	newCubeHVec[counter][0] = newCubeH[0];
	newCubeHVec[counter][1] = newCubeH[1] + 9;
	newCubeHVec[counter][2] = newCubeH[2];
}

//moves the cube
void changeCubeVectors() {
	newCubeAVec[counter][0] = newCubeAVec[counter][0] + particlesDir[counter][0];
	newCubeAVec[counter][1] = newCubeAVec[counter][1] + particlesDir[counter][1];
	newCubeAVec[counter][2] = newCubeAVec[counter][2] + particlesDir[counter][2];
	newCubeBVec[counter][0] = newCubeBVec[counter][0] + particlesDir[counter][0];
	newCubeBVec[counter][1] = newCubeBVec[counter][1] + particlesDir[counter][1];
	newCubeBVec[counter][2] = newCubeBVec[counter][2] + particlesDir[counter][2];
	newCubeCVec[counter][0] = newCubeCVec[counter][0] + particlesDir[counter][0];
	newCubeCVec[counter][1] = newCubeCVec[counter][1] + particlesDir[counter][1];
	newCubeCVec[counter][2] = newCubeCVec[counter][2] + particlesDir[counter][2];
	newCubeDVec[counter][0] = newCubeDVec[counter][0] + particlesDir[counter][0];
	newCubeDVec[counter][1] = newCubeDVec[counter][1] + particlesDir[counter][1];
	newCubeDVec[counter][2] = newCubeDVec[counter][2] + particlesDir[counter][2];
	newCubeEVec[counter][0] = newCubeEVec[counter][0] + particlesDir[counter][0];
	newCubeEVec[counter][1] = newCubeEVec[counter][1] + particlesDir[counter][1];
	newCubeEVec[counter][2] = newCubeEVec[counter][2] + particlesDir[counter][2];
	newCubeFVec[counter][0] = newCubeFVec[counter][0] + particlesDir[counter][0];
	newCubeFVec[counter][1] = newCubeFVec[counter][1] + particlesDir[counter][1];
	newCubeFVec[counter][2] = newCubeFVec[counter][2] + particlesDir[counter][2];
	newCubeGVec[counter][0] = newCubeGVec[counter][0] + particlesDir[counter][0];
	newCubeGVec[counter][1] = newCubeGVec[counter][1] + particlesDir[counter][1];
	newCubeGVec[counter][2] = newCubeGVec[counter][2] + particlesDir[counter][2];
	newCubeHVec[counter][0] = newCubeHVec[counter][0] + particlesDir[counter][0];
	newCubeHVec[counter][1] = newCubeHVec[counter][1] + particlesDir[counter][1];
	newCubeHVec[counter][2] = newCubeHVec[counter][2] + particlesDir[counter][2];

	//makes it so the particle falls off the edge if needed
	if (((newCubeBVec[counter][0] >= max) || (newCubeBVec[counter][0] <= -max) || (newCubeBVec[counter][2] >= max) || (newCubeBVec[counter][2] <= -max)) && newCubeBVec[counter][1] <= 0) {

		//makes it so the particles falling off the back dont get drawn
		if ((newCubeBVec[counter][0] <= -max) || (newCubeBVec[counter][2] <= -max)) {
			particles[counter][0] = 3;
		}

		//makes it so cubes disapear after falling off the edge a bit
		if (newCubeBVec[counter][1] <= -15 && particles[counter][0] != 3) {
			particles[counter][0] = 4;
		}

	}else if (newCubeBVec[counter][1] <= 0 ) {//if it hits the floor, it bounces

		if (frictionToggle == 1) {
			particles[counter][2]++;
			particlesDir[counter][1] = originalY / (particles[counter][2]);
		}else {
			particlesDir[counter][1] = -particlesDir[counter][1];
		}

		//makes it the particle eventually stops bouncing
		if (particlesDir[counter][1] <= 0.005) {
			particles[counter][0] = 4;
		}
	}
}

void resetParticle() {

}

void fountain() {

	//sorts the list from closest, to farthest from the viewer eye


	
	//for tracking time between each frame
	if (firstClock == 0) {
		start = clock();
		firstClock = 1;
	}
	stop = clock();

	//for tracking time between each particle shooting
	if (secondClock == 0) {
		startNextParticle = clock();
		secondClock = 1;
		numParticles++;
		nextParticle = clock();
	}

	if ((startNextParticle + fireingSpeed < nextParticle) && (numParticles < totalNumParticles)) {
		secondClock = 0;
	}
	nextParticle = clock();

	
	//if ( speed == 0 || start + 5 < stop) {
		glClear(GL_COLOR_BUFFER_BIT);

		//makes it so the particles falling off the back dont get drawn in front of the fountain, this doesnt work for some reason
		for (int i = 0; i < numParticles; i++) {
			counter = i;
			if ((newCubeBVec[counter][0] <= -max) || (newCubeBVec[counter][2] <= -max) && (particles[i][0] == 3) && (i <= numParticles)) {
				drawCube();

			}
		}

		drawFountain();

		for (int i = 0; i < numParticles; i++)
		{
			counter = i; 

			if (i <= numParticles) {

				//checks the state fo the particle, I made state = 1 at the top because state will be 1 more often then 0, 2 and 3
				if (particles[i][0] == 1) {
					//moves particle
					changeCubeVectors();
					drawCube();
					particlesDir[counter][1] = particlesDir[counter][1] - currentGravity;

				}else if (particles[i][0] == 0) {
					particles[counter][2] = 0;
					particlesDir[i][0] = 0;
					particlesDir[i][1] = 9;
					particlesDir[i][2] = 0;
					initCubeVectors();
					initColors();
					drawCube(0);

					//pick random direction
					particleDirection();

					particles[i][0] = 1;
				}else if (particles[i][0] == 2) {
					drawCube();

				}else if(particles[i][0] == 3 || particles[i][0] == 4){//cube disapears
					deleteParticle();
					numParticles--;
					i--;
					particles[numParticles][0] = 0;

				}else {
					//particles[i][0] = 0;
					//resetParticle();
					
				}

				firstClock = 0;
			}
		
		}
	//}else {
		//stop = clock();
	//}
	glutSwapBuffers();
}

void randomizeSpeeds() {

}

void reset() {
	counter = 0;
	numParticles = 0;
	start = clock();
	stop = clock();
	nextParticle = clock();
	startNextParticle = clock();
	firstClock = 0; 
	secondClock = 0; 
	numParticles = -1; 
	speed = 0; 
	fireingSpeed = 1;
	colourToggle = 0;
	frictionToggle = 0; 
	nextColor = 0; 

	for (int i = 0; i < totalNumParticles; i++) {
		for (int j = 0; j < 14; j++) {
			particles[i][j] = 0;
		}
	}

	for (int i = 0; i < totalNumParticles; i++) {
		for (int j = 0; j < 3; j++) {
			particlesDir[i][j] = 0;
		}
	}

	for (int i = 0; i < totalNumParticles; i++) {
		newCubeAVec[i][0] = newCubeA[0];
		newCubeAVec[i][1] = newCubeA[1];
		newCubeAVec[i][2] = newCubeA[2];
	}

	for (int i = 0; i < totalNumParticles; i++) {
		newCubeBVec[i][0] = newCubeB[0];
		newCubeBVec[i][1] = newCubeB[1];
		newCubeBVec[i][2] = newCubeB[2];
	}

	for (int i = 0; i < totalNumParticles; i++) {
		newCubeCVec[i][0] = newCubeC[0];
		newCubeCVec[i][1] = newCubeC[1];
		newCubeCVec[i][2] = newCubeC[2];
	}

	for (int i = 0; i < totalNumParticles; i++) {
		newCubeDVec[i][0] = newCubeD[0];
		newCubeDVec[i][1] = newCubeD[1];
		newCubeDVec[i][2] = newCubeD[2];
	}

	for (int i = 0; i < totalNumParticles; i++) {
		newCubeEVec[i][0] = newCubeE[0];
		newCubeEVec[i][1] = newCubeE[1];
		newCubeEVec[i][2] = newCubeE[2];
	}

	for (int i = 0; i < totalNumParticles; i++) {
		newCubeFVec[i][0] = newCubeF[0];
		newCubeFVec[i][1] = newCubeF[1];
		newCubeFVec[i][2] = newCubeF[2];
	}

	for (int i = 0; i < totalNumParticles; i++) {
		newCubeGVec[i][0] = newCubeG[0];
		newCubeGVec[i][1] = newCubeG[1];
		newCubeGVec[i][2] = newCubeG[2];
	}

	for (int i = 0; i < totalNumParticles; i++) {
		newCubeHVec[i][0] = newCubeH[0];
		newCubeHVec[i][1] = newCubeH[1];
		newCubeHVec[i][2] = newCubeH[2];
	}
}

void keyboard(unsigned char key, int x, int y) {

	switch (key) {
	case 'a':
	case 'A'://slow motion toggle
		if (speed == 0) {
			speed = 1;
			fireingSpeed = fireingSpeed * 2;
		}else {
			speed = 0;
			fireingSpeed = fireingSpeed / 2;
		}
		break;
	case 's':
	case 'S'://random speed toggle
		if (speed == 0) {
			
		}else {
			
		}
		break;
	case 'F':
	case 'f'://manual of stream generation

		break;
	case 'r':
	case 'R'://random spin toggle

		break;
	case 'g':
	case 'G'://friction on ground toggle
		if (frictionToggle == 0) {
			frictionToggle = 1;
		}else {
			frictionToggle = 0;
		}
		break;
	case 'c':
	case 'C'://colourful mode toggle
		if (colourToggle == 0) {
			colourToggle = 1;
		}else {
			colourToggle = 0;
		}
		break;
	case 'q':
	case 'Q':
		exit(0);

		break;
	case 'w'://resets the simulation
	case 'W':
		reset();
		break;
	}
}

main(int argc, char** argv) {
	srand(time(0));
	glutInit(&argc, argv);
	glutInitWindowSize(900, 600);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
	glutCreateWindow("glLookat example");

	glutKeyboardFunc(keyboard);

	glutDisplayFunc(fountain);
	glutIdleFunc(fountain);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(30.0, 1.5, 0.1, 250.0);
	gluLookAt(45, 30, 150, -5.5, 5, 0, 0, 1.0, 0.0);

	glMatrixMode(GL_MODELVIEW);

	glClearColor(0, 0, 0, 0);  /* black */

	
	
	glutMainLoop();
	return 0;
}
